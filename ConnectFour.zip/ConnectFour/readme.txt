Connect4 
----------

software requirement : VS2017 or VS 2019
--Build application for Nuget Package Restore